# Panriya - Class 1 Games (Android APK)

## Steps (GitHub par upload karke APK banane ke liye)

1. GitHub par ek naya **repository** banao (public ya private, dono chalega).
2. Is zip ko **extract** karo, phir GitHub repo mein **saari files upload** karo
   (folder structure waisa hi rakhna: `www/index.html`, `.github/workflows/build-apk.yml`, `package.json`, `capacitor.config.json`).
3. Upload/commit hote hi GitHub **Actions** tab mein "Build Android APK" workflow apne aap chalega
   (agar na chale to Actions tab mein ja kar "Run workflow" par click karo).
4. Workflow complete hone ke baad (5-10 minute lagte hain), usi run ke neeche
   **Artifacts** section mein "chhota-scholar-app" naam ka zip milega — usme APK hai.
5. Wo APK download karke apne phone par install kar sakte ho
   (phone mein "unknown sources / install from this source" allow karna hoga).

## Note
- Ye **debug APK** hai (testing ke liye). Play Store par publish karne ke liye
  signed **release APK** chahiye hoga — agar zaroorat ho to bata dena, wo bhi bana denge.
- App ka naam ab "Panriya" hai, package id `com.panriya.class1games`;
  chaho to `capacitor.config.json` mein badal sakte ho.
- App icon `resources/icon.png` mein hai (colorful star + pencil design). Workflow
  build ke time is se apne aap Android ke saare icon sizes (launcher icon) generate
  kar deta hai. Icon badalna ho to bas `resources/icon.png` (1024x1024) replace kar dena.
